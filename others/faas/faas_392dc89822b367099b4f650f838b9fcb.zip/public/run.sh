#!/bin/bash
LD_LIBRARY_PATH=/home/ctf ./faas NUCLEO_L152RE.bin
