#!/bin/bash
docker build -t faas:latest .