#!/bin/bash
docker run -p 4444:4444 -i -t faas:latest